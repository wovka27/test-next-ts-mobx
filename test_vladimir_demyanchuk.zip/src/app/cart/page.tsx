import React from 'react'
import CartComponent from '@/entities/cart/ui/CartComponent'

const CartPage: React.FC =() => {
  return <CartComponent />
}

export default CartPage