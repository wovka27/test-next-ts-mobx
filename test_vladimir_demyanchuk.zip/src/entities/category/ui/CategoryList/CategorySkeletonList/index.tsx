const CategorySkeletonList = () => {
  return null
}

export default CategorySkeletonList