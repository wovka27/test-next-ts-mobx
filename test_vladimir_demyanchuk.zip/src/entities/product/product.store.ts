import { makeObservable, observable, action, runInAction } from 'mobx'
import { queueProcessor } from 'mobx-utils'
import { type IProductItem } from '@/entities/product/product.model'
import { getProductsItems } from '@/entities/product/api/getProductItems'
import categoryStore from '@/entities/category/category.store'
import { ICategory } from '@/entities/category/category.model'

export default class ProductStore {
  @observable private queue: number[] = []
  @observable products: IProductItem[] = []
  @observable is_loading = false
  @observable categories = categoryStore.list
  @observable has_more = true
  private batch_size = 25

  constructor() {
    makeObservable(this)

    // Обрабатываем очередь загрузки товаров
    queueProcessor(this.queue, async (start) => {
      await this.loadProducts(start, start + this.batch_size - 1)
    })
  }

  @action async loadProducts(start: number, end: number) {
    if (this.is_loading || !this.has_more) return

    const param = new URLSearchParams(window.location.search).get('categoryId')
    const category_id: number[] = JSON.parse(param?.length ? param : '[8]')
    const categories = await this.categories

    this.is_loading = true
    try {
      const data = await getProductsItems([start, end], {
        category_id: category_id.includes(0)
          ? (categories ?? ([] as ICategory[]))!.map((i) => i.id)
          : category_id.length
            ? category_id
            : [8]
      })

      runInAction(() => {
        const existingIds: Map<number, IProductItem> = new Map(this.products.map((i) => [i.id, i]))

        data.forEach((i) => existingIds.set(i.id, i))

        this.products = Array.from(existingIds.values())
        this.products.push(...data)

        // Проверяем, есть ли ещё товары для загрузки
        if (data.length < this.batch_size) this.has_more = false
      })
    } catch (error) {
      console.error('Ошибка загрузки товаров:', error)
    } finally {
      this.is_loading = false
    }
  }

  @action loadNextBatch() {
    if (this.has_more) {
      this.queue.push(this.products.length)
    }
  }
}
